package com.app.fruits;

import java.util.Scanner;

public class FruitBasket {

    public static int menuList(Scanner sc) {
        System.out.println("\n0.Exit");
        System.out.println("1.Add Mango");
        System.out.println("2.Add Orange");
        System.out.println("3.Add Apple");
        System.out.println("4.Display names of all fruits");
        System.out.println("5.Display all fresh fruit details");
        System.out.println("6.Mark fruit as stale");
        System.out.println("7.Display tastes of all stale fruits");
        return sc.nextInt();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter basket size: ");
        int basketSize = sc.nextInt();
        sc.nextLine(); 

        Fruit[] basket = new Fruit[basketSize];
        int counter = 0;

        int choice;
        while ((choice = menuList(sc)) != 0) {
            switch (choice) {
                case 1:
                    if (counter < basketSize) {
                        System.out.println("Enter name, weight, and color:");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        sc.nextLine();
                        String color = sc.next();
                        basket[counter++] = new Mango(color, weight, name);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;
                case 2:
                    if (counter < basketSize) {
                        System.out.println("Enter name, weight, and color:");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        sc.nextLine();
                        String color = sc.next();
                        basket[counter++] = new Orange(color, weight, name);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;
                case 3:
                    if (counter < basketSize) {
                        System.out.println("Enter name, weight, and color:");
                        String name = sc.next();
                        double weight = sc.nextDouble();
                        sc.next();
                        String color = sc.next();
                        basket[counter++] = new Apple(color, weight, name);
                    } else {
                        System.out.println("Basket is full!");
                    }
                    break;
                case 4:
                    System.out.println("Fruits in basket:");
                    for (Fruit fruits : basket) {
                        if (fruits != null)
                            System.out.println(fruits.getName());
                    }
                    break;
                case 5:
                    System.out.println("Fresh fruit details:");
                    for (Fruit fruits : basket) {
                        if (fruits != null && fruits.getIsFresh()) {
                            System.out.println(fruits.toString());
                            System.out.print(fruits.getName() + " taste : ");
                            fruits.taste();
                        }
                    }
                    break;
                case 6:
                    System.out.println("Enter index to mark as stale:");
                    int i = sc.nextInt();
                    sc.nextLine();
                    if (i >= 0 && i < counter && basket[i] != null) {
                        basket[i].setIsFresh(false);
                        System.out.println("stale successfully.");
                    } else {
                        System.out.println("Invalid index!");
                    }
                    break;
                case 7:
                    System.out.println("Stale fruit tastes:");
                    for (Fruit fruits : basket) {
                        if (fruits != null && !fruits.getIsFresh()) {
                            System.out.print(fruits.getName() + " Taste -> ");
                            fruits.taste();
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }

        sc.close();
    }
}
