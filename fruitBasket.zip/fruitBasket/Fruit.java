package com.app.fruits;

public class Fruit {
    protected String color;
    protected double weight;
    protected String name;
    protected boolean isFresh;

    public Fruit(String color, double weight, String name) {
        this.color = color;
        this.name = name;
        this.weight = weight;
        this.isFresh = true;
    }

    public String getName() {
        return name;
    }

    public void setIsFresh(boolean isFresh) {
        this.isFresh = isFresh;
    }

    public boolean getIsFresh() {
        return isFresh;
    }

    public void taste() {
        System.out.println("No specific taste");
    }

    @Override
    public String toString() {
        return "Fruit -> ( Name: " + this.name +", Color: " + this.color +  ", Weight: " + this.weight + ")";
    }
}