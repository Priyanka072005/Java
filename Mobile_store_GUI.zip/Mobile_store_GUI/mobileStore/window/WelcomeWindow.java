package com.mobileStore.window;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class WelcomeWindow extends JFrame{
	JLabel labelName;
	JButton login;
	JButton signIn;
	
	public WelcomeWindow(){
		this.setTitle("Welcome");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		
		labelName = new JLabel("Welcome to the mobile store");
		login = new JButton("Login");
		signIn = new JButton("SignIn");
		
		labelName.setBounds(360, 200, 200, 50);	
		login.setBounds(300, 280, 80, 30);
		signIn.setBounds(500, 280, 80, 30);
		
		this.add(labelName);
		this.add(login);
		this.add(signIn);
		
		login.addActionListener(e->{
			LoginWindow loginWindow = new LoginWindow();
			loginWindow.setSize(900,600);
			loginWindow.setVisible(true);
			this.dispose();
		});
		
		signIn.addActionListener(e->{
			RegisterDialogBox registerBox = new RegisterDialogBox();
			registerBox.setSize(900, 600);
			registerBox.setModal(true);
			
			registerBox.setVisible(true);
			this.dispose();
		});
	}
}
