package com.mobileStore.window;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mobileStore.entity.User;
import com.mobileStore.main.Program;


public class RegisterDialogBox extends JDialog{
	JLabel labelName;
	JLabel labelEmail;
	JLabel labelPassword;
	JLabel labelCity;
	
	JTextField textName;
	JTextField textEmail;
	JTextField textPassword;
	JTextField textCity;
	
	JButton register;
	
	public RegisterDialogBox() {
		this.setTitle("Register");
		this.setLayout(null);
		
		labelName = new JLabel("Name : ");
		labelEmail = new JLabel("Email : ");
		labelPassword = new JLabel("Password: ");
		labelCity = new JLabel("City : ");

		textName = new JTextField();
		textEmail = new JTextField();
		textPassword = new JTextField();
		textCity = new JTextField();
		
		register = new JButton("Register");
		
		labelName.setBounds(50, 50, 80, 30);
		textName.setBounds(140,50,150,30);
		labelEmail.setBounds(50, 100, 80, 30);
		textEmail.setBounds(140,100,150,30);

		labelPassword.setBounds(50, 150, 80, 30);
		textPassword.setBounds(140,150,150,30);

		labelCity.setBounds(50, 200, 80, 30);
		textCity.setBounds(140,200,150,30);
		
		register.setBounds(80, 250, 200, 30);
		
		this.add(labelName);
		this.add(textName);
		this.add(labelCity);
		this.add(labelEmail);
		
		this.add(textCity);
		this.add(textEmail);
		this.add(labelPassword);
		this.add(textPassword);
		
		this.add(register);
		
		register.addActionListener(e -> {
			User user = new User();
			user.setName(textName.getText());
			user.setCity(textCity.getText());
			user.setEmail(textEmail.getText());
			user.setPassword(textPassword.getText());
			
			Program.addUser(user);
			JOptionPane.showMessageDialog(RegisterDialogBox.this, "Registration successful");
			this.dispose();
			
			LoginWindow login = new LoginWindow();
			login.setSize(900, 600);
			login.setVisible(true);
			this.dispose();
		});
		



		
	}
}
