package com.mobileStore.window;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mobileStore.entity.User;
import com.mobileStore.main.Program;

public class LoginWindow extends JFrame{
	JLabel labelEmail;
	JLabel labelPassword;
	JTextField textEmail;
	JTextField textPassword;
	JButton loginButton;
	JButton registerButton;
	
	public LoginWindow() {
		this.setTitle("Login");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		
		labelEmail = new JLabel("Email : ");
		labelPassword = new JLabel("Password : ");
		textEmail = new JTextField();
		textPassword = new JTextField();
		loginButton = new JButton("Login");
		registerButton = new JButton("Register");
		
		labelEmail.setBounds(50, 50, 80, 30);
		textEmail.setBounds(140, 50, 180, 30);
		labelPassword.setBounds(50, 100, 80, 30);
		textPassword.setBounds(140, 100, 180, 30);
		loginButton.setBounds(60,150,100,30);
		registerButton.setBounds(180,150,100,30);
		
		
		this.add(labelEmail);
		this.add(labelPassword);
		this.add(loginButton);
		this.add(registerButton);
		this.add(textEmail);
		this.add(textPassword);
		
		loginButton.addActionListener(e ->{
			String email = textEmail.getText();
			String password = textPassword.getText();
			User user = Program.userLogin(email, password);
			if(user != null) {
				JOptionPane.showMessageDialog(LoginWindow.this, "Login Successful");
				
				Home home = new Home(user);
				home.setSize(900, 600);
				home.setVisible(true);
				this.dispose();
				
				
			}else {
				JOptionPane.showMessageDialog(LoginWindow.this,"Invalid Credientials");
			}
		});
		
		registerButton.addActionListener(e->{
			RegisterDialogBox registerBox = new RegisterDialogBox();
			registerBox.setSize(900, 600);
			registerBox.setModal(true);
			registerBox.setVisible(true);
			this.dispose();
		});
	}
}
