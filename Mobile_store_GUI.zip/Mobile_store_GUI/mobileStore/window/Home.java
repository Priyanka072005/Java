package com.mobileStore.window;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mobileStore.entity.Mobile;
import com.mobileStore.entity.User;
import com.mobileStore.main.Program;

public class Home extends JFrame{
	User user;
	JLabel labelGretting;
	JButton purchaseButton;
	JButton ordersButton;
	JButton addMobileButton;
	JButton refreshButton;
	JButton logout;
	JTable productTable;
	
	JScrollPane scrollPane;
	List<Mobile> mobileList;
	
	
	
	public Home(User user){
		this.setTitle("Home Page");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		this.user = user;
		
		labelGretting = new JLabel("Hello " + user.getName());
		purchaseButton = new JButton("Buy");
		ordersButton = new JButton("Orders");
		addMobileButton = new JButton("Add Mobile");
		refreshButton = new JButton("Refresh");
		logout = new JButton("Logout");
		
		labelGretting.setBounds(20, 20, 100, 30);
		purchaseButton.setBounds(50,50,100,30);
		ordersButton.setBounds(160,50,100,30);
		addMobileButton.setBounds(270,50,100,30);
		refreshButton.setBounds(380,50,100,30);
		logout.setBounds(700, 30, 100, 30);
		
		this.add(labelGretting);
		this.add(purchaseButton);
		this.add(ordersButton);
		this.add(addMobileButton);
		this.add(refreshButton);
		this.add(logout);
		
	
		Object[] colNames = {"Mobileid","Company","Model","Price"};
		
		DefaultTableModel defaultTableModel = new DefaultTableModel(colNames,0);
		productTable = new JTable(defaultTableModel);
		defaultTableModel.setRowCount(0);
		mobileList = Program.getAllMobile();
		mobileList.forEach(m ->{
			defaultTableModel.addRow( new Object[] {m.getMobileid() , m.getCompany(),m.getModel(),m.getPrice()});
		});
		
		scrollPane = new JScrollPane(productTable);
		scrollPane.setBounds(50, 100, 480, 500);
		this.add(scrollPane);

		refreshButton.addActionListener(e ->{
			defaultTableModel.setRowCount(0);
			mobileList = Program.getAllMobile();
			mobileList.forEach(m ->{
				defaultTableModel.addRow( new Object[] {m.getMobileid() , m.getCompany(),m.getModel(),m.getPrice()});
			});
		});
		
		purchaseButton.addActionListener(e ->{
			int  rowindex = productTable.getSelectedRow();
			if(rowindex == -1) {
				JOptionPane.showMessageDialog(null, "Please select a row to purchase");
			}
			int mobileid = (Integer) productTable.getValueAt(rowindex, 0);
			Program.placeOrder(mobileid, user.getUserid());
			String message = "You Purchaes a - "+productTable.getValueAt(rowindex, 1) + " - "
					+productTable.getValueAt(rowindex, 2) + "at Rs. "+productTable.getValueAt(rowindex, 3);
			JOptionPane.showMessageDialog(Home.this, message);
		});

		ordersButton.addActionListener(e->{
			OrderHistoryDialogBox orderhistorydialog = new OrderHistoryDialogBox(user);
			orderhistorydialog.setSize(900, 600);
			orderhistorydialog.setModal(true);
			orderhistorydialog.setVisible(true);
			this.dispose();
		});
		
		addMobileButton.addActionListener(e->{
			AddMobileWindow addMobile = new AddMobileWindow();
			addMobile.setSize(900,600);
			addMobile.setVisible(true);
			this.dispose();
			
		});
		
		logout.addActionListener(e->{
			Program.logout(user);
			LoginWindow login = new LoginWindow();
			login.setSize(900, 600);
			login.setVisible(true);
			this.dispose();
		});
	}
	
	
}
