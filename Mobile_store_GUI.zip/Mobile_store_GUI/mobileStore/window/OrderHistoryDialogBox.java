package com.mobileStore.window;

import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mobileStore.entity.Mobile;
import com.mobileStore.entity.User;
import com.mobileStore.main.Program;

public class OrderHistoryDialogBox extends JDialog{
	JTable productTable;
	JScrollPane scrollPane;
	JButton back;
	List<Mobile>mobileList;

	
	 public OrderHistoryDialogBox(User user) {
		 this.setTitle("order history");
		 this.setLayout(null);
		 
		 Object[] colNames = {"mobileid", "company", "model", "price"};
		 DefaultTableModel defaultTableModel = new DefaultTableModel(colNames, 0);
		 
		try {
			mobileList = Program.ordersHistory(user.getUserid());
			mobileList.forEach(m ->{
				defaultTableModel.addRow(new Object[] {m.getMobileid(), m.getCompany(), m.getModel(), m.getPrice()});
			});
		}catch(Exception e) {
			e.printStackTrace();
		}
			
			productTable = new JTable(defaultTableModel);
			scrollPane = new JScrollPane(productTable);
			scrollPane.setBounds(50, 50, 500, 400);
			this.add(scrollPane);
			
			back = new JButton("Back");
			back.setBounds(200, 500, 300, 40);
			this.add(back);
			
			back.addActionListener(e ->{
				Home home = new Home(user);
				home.setSize(900,600);
				home.setVisible(true);
				this.dispose();
			});
	 }
	
}
