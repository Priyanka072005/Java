package com.mobileStore.window;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.mobileStore.entity.Mobile;
import com.mobileStore.entity.User;
import com.mobileStore.main.Program;

public class AddMobileWindow extends JFrame{
	JLabel labelid;
	JLabel labelCompany;
	JLabel labelModel;
	JLabel labelPrice;
	
	JTextField textid;
	JTextField textCompany;
	JTextField textModel;
	JTextField textPrice;
	
	JButton add;
	JButton back;
	
	public AddMobileWindow() {
		this.setTitle("Add mobile");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(null);
		
		labelid = new JLabel("Mobile id : ");
		labelCompany = new JLabel("Company : ");
		labelModel = new JLabel("Model : ");
		labelPrice = new JLabel("Price : ");
		
		textid = new JTextField();
		textCompany = new JTextField();
		textModel = new JTextField();
		textPrice = new JTextField();
		
		add = new JButton("Add");
		back = new JButton("Back");

		labelid.setBounds(50, 50, 100, 30);
		labelCompany.setBounds(50, 100, 100, 30);
		labelModel.setBounds(50, 150, 100, 30);
		labelPrice.setBounds(50, 200, 100, 30);
		
		textid.setBounds(170, 50, 150, 30);
		textCompany.setBounds(170, 100, 150, 30);
		textModel.setBounds(170, 150, 100, 30);
		textPrice.setBounds(170, 200, 100, 30);
		
		add.setBounds(60, 250, 200, 30);
		back.setBounds(300, 250, 200, 30);
		
		this.add(labelid);
		this.add(labelCompany);
		this.add(labelModel);
		this.add(labelPrice);
		this.add(textid);
		this.add(textCompany);
		this.add(textModel);
		this.add(textPrice);
		this.add(add);
		this.add(back);
		
		User user = new User();

		add.addActionListener(e->{
			Mobile mobile = new Mobile();
			mobile.setCompany(textCompany.getText());
			mobile.setModel(textModel.getText());
			mobile.setPrice((Double.parseDouble(textPrice.getText())));
			Program.addMobile(mobile);
			JOptionPane.showMessageDialog(AddMobileWindow.this, "Add mobile successfully");
			this.dispose();
			Home home = new Home(user);
			home.setVisible(true);
			
		});
		
		back.addActionListener(e->{
			Home home = new Home(user);
			home.setSize(900, 600);
			home.setVisible(true);
			this.dispose();
		});

		
	}
	
}
