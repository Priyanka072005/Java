package com.mobileStore.entity;

public class Mobile {
	private int mobileid;
	private String company;
	private String model;
	private double price;
	
	public Mobile() {
		
	}

	public Mobile(int mobileid, String company, String model, double price) {
		super();
		this.mobileid = mobileid;
		this.company = company;
		this.model = model;
		this.price = price;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "[mobileid=" + mobileid + ", company=" + company + ", model=" + model + ", price=" + price + "]";
	}

	
	
	
}
