package com.mobileStore.main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mobileStore.entity.Mobile;
import com.mobileStore.entity.User;
import com.mobileStore.util.Dbutil;
import com.mobileStore.window.LoginWindow;
import com.mobileStore.window.WelcomeWindow;

public class Program {
	
	public static void addUser(User user) {
		String sql = "INSERT INTO user(name,email,password,city) VALUES(?,?,?,?)";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement insert = conn.prepareStatement(sql)){
				insert.setString(1, user.getName());
				insert.setString(2, user.getEmail());
				insert.setString(3, user.getPassword());
				insert.setString(4, user.getCity());
				insert.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void addMobile(Mobile mobile) {
		String sql = "INSERT INTO mobile(company,model,price)VALUES(?,?,?)";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement insert = conn.prepareStatement(sql)){
				insert.setString(1, mobile.getCompany());
				insert.setString(2, mobile.getModel());
				insert.setDouble(3, mobile.getPrice());
				insert.executeUpdate();
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static User userLogin(String email,String password) {
		User user = new User();
		user.setEmail(email);
		user.setPassword(password);
		
		String sql = "SELECT * FROM user WHERE email = ? AND password = ?";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement select = conn.prepareStatement(sql)){
				select.setString(1, user.getEmail());
				select.setString(2, user.getPassword());
				ResultSet rs = select.executeQuery();
				if(rs.next()) {
					user.setUserid(rs.getInt("userid"));
					user.setName(rs.getString("name"));
					user.setCity(rs.getString("city"));
					return user;	
				}
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static List<Mobile> getAllMobile() {
		String sql = "SELECT * FROM mobile";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement insert = conn.prepareStatement(sql)){
				ResultSet rs = insert.executeQuery();
				List<Mobile>mobileList = new ArrayList<>();
				while(rs.next()) {
					Mobile mobile = new Mobile();
					mobile.setMobileid(rs.getInt(1));
					mobile.setCompany(rs.getString(2));
					mobile.setModel(rs.getString(3));
					mobile.setPrice(rs.getDouble(4));
					mobileList.add(mobile);
				}
				return mobileList;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void placeOrder(int mobileid, int userid) {
		String sql = "INSERT INTO orders(mobileid, userid) VALUES(?,?)";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement insert = conn.prepareStatement(sql)){
				insert.setInt(1, mobileid);
				insert.setInt(2, userid);
				insert.executeUpdate();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static List<Mobile> ordersHistory(int userid) {
		String sql = "SELECT m.mobileid,m.company,m.model,m.price FROM mobile m INNER JOIN orders o ON m.mobileid = o.mobileid WHERE o.userid = ?";
		try(Connection conn = Dbutil.getConnection()){
			try(PreparedStatement select = conn.prepareStatement(sql)){
				select.setInt(1, userid);
				ResultSet rs = select.executeQuery();
				List<Mobile>mobileList = new ArrayList<>();
				while(rs.next()) {
					Mobile mobile = new Mobile();
					mobile.setMobileid(rs.getInt(1));
					mobile.setCompany(rs.getString(2));
					mobile.setModel(rs.getString(3));
					mobile.setPrice(rs.getDouble(4));
					mobileList.add(mobile);
				}
				return mobileList;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static User logout(User user) {
		user = null;
		return user;
	}
	
	public static void main(String[] args) {
		WelcomeWindow welcome = new WelcomeWindow();
		welcome.setSize(900, 600);
		welcome.setVisible(true);
		
		
	}
}
